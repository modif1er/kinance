export const history = {
  navigate: null,
  location: null
};