import { Position, Toaster } from "@blueprintjs/core";
 
export const appToaster = Toaster.create({
    className: "recipe-toaster",
    position: Position.TOP,
})